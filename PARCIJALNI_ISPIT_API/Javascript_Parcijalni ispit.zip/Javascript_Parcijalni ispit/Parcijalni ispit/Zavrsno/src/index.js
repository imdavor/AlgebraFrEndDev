import app from 'main';

document.addEventListener('DOMContentLoaded', () => {
	app();
});
