export default `
  <div class="loader">
    <div class="spinner"></div>
  </div>
`;
