export default `
  <div>
    <div>
      <input type="text" id="search" />
    </div>
    <div id="content">
    </div>
  </div>
`;
