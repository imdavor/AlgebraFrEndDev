export function render({ markup, el }) {
	el.innerHTML = markup;
}
