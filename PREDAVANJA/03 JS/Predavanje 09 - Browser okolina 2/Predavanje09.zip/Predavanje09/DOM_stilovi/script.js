var p = document.querySelector("p");
p.style.color = "red";

//document.querySelector("#cube").classList.add("cube");
var cube = document.querySelector("#cube"); 
cube.classList.add("cube");

var cubeStyles = window.getComputedStyle(cube);
var cubeLeftPosition = cubeStyles.getPropertyValue("left");
console.log(cubeLeftPosition);

var cubeLeftMargin = parseInt(cubeStyles.getPropertyValue("margin-left"));
var cubeWidth = parseInt(cubeStyles.getPropertyValue("width"));
var windowWidth = window.innerWidth;
var maxPosition = windowWidth - cubeWidth;

function animate(){
    console.log("radi");
    if (cubeLeftMargin == maxPosition) {
        clearInterval(intId);
        return;
    }
    cube.style.marginLeft = cubeLeftMargin + "px";
    cubeLeftMargin++;
}

var intId = setInterval(animate, 10);

var divText = document.querySelector("#cube + div");
divText.classList.toggle("hide");