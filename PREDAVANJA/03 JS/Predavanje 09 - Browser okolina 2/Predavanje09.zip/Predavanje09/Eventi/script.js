var algebraLink = document.querySelector(".algebra");
var finaLink = document.querySelector(".fina");

algebraLink.addEventListener("click", handleLinkClick);
finaLink.addEventListener("click", handleLinkClick);

function handleLinkClick(event) {
    event.preventDefault();
    event.stopPropagation();
    
    if (confirm("Da li si siguran?")) {
        window.location.assign(event.target.href);
    }
}

var body = document.querySelector("body");
body.addEventListener("click", function(e){
    console.log("kliknuo si na body element!");
})