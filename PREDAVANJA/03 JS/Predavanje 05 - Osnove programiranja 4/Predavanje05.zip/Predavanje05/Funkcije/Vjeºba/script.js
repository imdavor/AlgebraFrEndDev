/* Napravite funkciju koja uzima dva argumenta. Oba argumenta su cijeli brojevi, a i b. Vrati true ako je jedan od njih 10 ili ako je njihov zbroj 10. */

function checkTen(a, b) {
    var x = parseInt(a);
    var y = parseInt(b);

    if (isNaN(x) || isNaN(y)) {
        return false;
    }

    return [x,y,x+y].includes(10);
}

console.log(checkTen(7,1)); //false
console.log(checkTen(10,5)); //true
console.log(checkTen(5,10)); //true
console.log(checkTen(7,3)); //true  
console.log(checkTen("Pero",3)); //false
console.log(checkTen("7",3)); //true
console.log(checkTen(10,0)); //false