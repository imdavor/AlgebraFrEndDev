function ispisiTekst() {
    console.log("Tekst ispisan iz funkcije");
}

var rezultatFunkcijeIspisiTekst = ispisiTekst();
console.log(rezultatFunkcijeIspisiTekst);

function zbrojiDvaBroja(x = 0, y = 0){
    return x + y;
}

var zbroj = zbrojiDvaBroja(4,5);
console.log(zbroj);
