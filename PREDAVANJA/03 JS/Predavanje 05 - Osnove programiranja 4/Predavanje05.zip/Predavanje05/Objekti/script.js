var user = {
    firstName: "Anita",
    lastName: "Antić",
}

console.log(user.firstName);
user.firstName = "Ante";
console.log(user.firstName);

Object.defineProperty(user, "oib", {
    value: 125455865636,
    writable: false
})

user.oib = 5115689545;
console.log(user);

var arhiver = {
    temperature: null,
    archive: [],
    setTemperature: function (temp) {
        arhiver.temperature = temp;
        arhiver.archive.push({
            date: new Date(),
            temp: temp
        });
    }
}

arhiver.setTemperature(15);
arhiver.setTemperature(10);
arhiver.setTemperature(5);

console.log(arhiver);