var tableBody = document.querySelector("#students tbody");

for(var i = 0; i < students.length; i++){
    var student = students[i];
    
    var tr = document.createElement("tr");

    var rbrTd = document.createElement("td");
    rbrTd.innerText = i + 1 + ".";
    tr.append(rbrTd);

    var nameTd = document.createElement("td");
    nameTd.innerText = student.firstName;
    tr.append(nameTd);

    var surnameTd = document.createElement("td");
    surnameTd.innerText = student.lastName;
    tr.append(surnameTd);

    var jmbagTd = document.createElement("td");
    jmbagTd.innerText = student.jmbag;
    tr.append(jmbagTd);

    tableBody.append(tr);
}



bindData(students, "#studenti", "div");
//bindData(students, "#students tbody", "tr");

function bindData(data, root, element) {
    var rootElement = document.querySelector(root);

    data.map(function(value, index){
        rootElement.append(createElementAndBindData(value, index, element));
    });
}

function createElementAndBindData(data, index, element) {
    var row = document.createElement(element);
    var cell = row.cloneNode(true);
        cell.innerText = index + 1;
        row.append(cell);

    for (var key in data) {
        var element = data[key];
        var dataCell = row.cloneNode(true)
        dataCell.innerText = element;
        row.append(dataCell);
    }

    return row;    
}