var students = [
    {
        jmbag: "158488664646",
        firstName: "Pero",
        lastName: "Perić"
    },
    {
        jmbag: "0054186484774",
        firstName: "Ana",
        lastName: "Anić"
    },
    {
        jmbag: "4578845868",
        firstName: "Mirko",
        lastName: "Mirkić"
    },
    {
        jmbag: "38584786",
        firstName: "Iva",
        lastName: "Ivić"
    },
    {
        jmbag: "8899445748",
        firstName: "Ante",
        lastName: "Antić"
    },
    {
        jmbag: "006674777",
        firstName: "Mirta",
        lastName: "Mirtić"
    },
];