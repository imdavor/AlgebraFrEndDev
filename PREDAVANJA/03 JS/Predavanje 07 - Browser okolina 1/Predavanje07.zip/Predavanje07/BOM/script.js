var a = 10;
console.log(window);
console.log(document);
console.log(this);
console.log(a);
console.log(window.location.hostname);
console.log(window.location.href);

//window.location.href = 'http://google.com';
//window.location.assign('http://google.com');



setTimeout(function(){
    console.log("Kasnim 2 sec!");
}, 2000);

var intervalId = setInterval(function () {
    console.log("Bok");
}, 2000);

clearInterval(intervalId);

var time = 10;
var inerval = setInterval(function(){
    
    time--;
    
    if (time == 0) {
        clearInterval(inerval);
        
    }

    console.log(time);
}, 1000);