var header = document.querySelector("#header");
var mainTitle = header.children[0];
//mainTitle.className = mainTitle.className + " dark";
mainTitle.classList.add("dark");

console.log(mainTitle.innerHTML);

var subtitle = document.createElement("h2");
subtitle.innerText = "Mijenjanje DOM strukture";
header.append(subtitle);


var footer = document.querySelector("#footer"); 
var ul = footer.querySelector("ul"); 

console.log(ul);

var newUser =  document.createElement("li");
newUser.innerText = "Mirko Mirkić";
newUser.dataset.userId = 3;
ul.append(newUser);

var copyUser = newUser.cloneNode(true);
copyUser.innerText = "Anita";
ul.append(copyUser);

var listElements = ul.querySelectorAll("li");
console.log(listElements);

listElements.forEach(function(value){
    if(value.innerText.includes("Mir")){
        value.remove();
    }
});