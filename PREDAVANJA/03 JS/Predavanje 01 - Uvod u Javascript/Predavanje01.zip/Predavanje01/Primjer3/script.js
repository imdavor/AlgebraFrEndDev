var body = document.querySelector("body");

console.log(body.clientWidth);