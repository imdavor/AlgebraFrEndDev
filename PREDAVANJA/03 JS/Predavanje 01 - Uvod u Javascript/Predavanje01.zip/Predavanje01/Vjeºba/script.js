var div = document.querySelector("div");

console.log(div);

/*
1. Uključite JS skriptu u stranicu na 4 različita načina (kreirajte 4 različita index.html-a): u head-u, prije završetka body taga, sa defer atributom i sa async atributom.
2. Proučite rezultate u Chrome DevTools konzoli za svaki od dokumenata.
 */