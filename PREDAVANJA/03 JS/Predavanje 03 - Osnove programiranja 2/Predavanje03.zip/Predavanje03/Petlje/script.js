var iterator = 0;

while (iterator < 10) {
    console.log(iterator);
    iterator++;
}

do {
    console.log(iterator);
    iterator++;
} while (iterator < 10)


for(var i = 0; i < 10; i++){
    if (i == 3) {
        continue;
    }
    console.log(i);

    if (i == 4) {
        break;
    }
}

for(var i = 1; i <= 4; i++){
    for(var j = 1; j <= 4; j++){
        console.log(i + "/" + j);
    }
}

var number, isRepeat;

do {
    number = prompt("Unesi neki broj!");
    number = Number(number);

    if (isNaN(number)) {
        alert("Nisi upisao broj!");
        isRepeat = true;
    } else {
        console.log(number);
        isRepeat = false;
    }
} while (isRepeat);
