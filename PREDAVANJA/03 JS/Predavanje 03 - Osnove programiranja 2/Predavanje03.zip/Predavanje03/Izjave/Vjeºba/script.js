var a = 46;
var b = 8;
var c = 71;

if ((a < b && b < c) || (a > b && b > c)) {
    console.log();
} else {
    console.log();
}