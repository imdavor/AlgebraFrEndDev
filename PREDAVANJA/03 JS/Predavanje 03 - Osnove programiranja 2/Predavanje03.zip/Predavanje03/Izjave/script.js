var a = 5;
var b = 10;

if (a > 10) {
    console.log("var a je veći od 10!");
}

if (b > 10) {
    console.log("var b je veći od 10!");
}

if (a <= 10) {
    console.log("var a je manji od ili jednak 10!");
} else {
    console.log("var a je veći od 10!");
}

if (a < 10) {
    console.log("var a je manji od 10!");
} else if (a == 10) {
    console.log("var a je jednako 10!");
}else {
    console.log("var a je veći od 10!");
}

if (a < 10) {
    console.log("var a je manji od 10");

    if (a == 5) {
        console.log("var a je jednak 5");
    }
}

if (a < 10 && a == 5) {
    console.log("var a je jednak 5");
}

var num = 3;

switch (num) {
    case 1:
        console.log("Osvojio si zlato");
        break;
    case 2:
        console.log("Osvojio si srebro");
        break;
    case 3:
        console.log("Osvojio si broncu");
        break;

    default:
        console.log("Osvojio si frišku figu");
        break;
}