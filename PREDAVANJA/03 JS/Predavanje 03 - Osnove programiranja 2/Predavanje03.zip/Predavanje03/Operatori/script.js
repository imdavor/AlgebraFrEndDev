var a = 0;
var b = 3;

console.log(b / a);
console.log(a % b);

console.log(a == b);
console.log(a != b);

console.log(!a);
console.log(!b - 3);
console.log(!(b - 3));


a++;
a = a + 5;
// a += 1
console.log(a);

let c = ++b;
console.log(c);
console.log(b++);

var d = a < b && b == c;

console.log(d);
console.log();