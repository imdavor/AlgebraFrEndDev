var countries = ["Maroko", "Hrvatska", "Belgija",  "Kanada"];
console.log(countries);
console.log(countries[4]);

for(var i = 0; i < countries.length; i++){
    console.log(countries[i]);
}

countries[5] = "Italija";
console.log(countries);

// Dodavanje elemenata u niz
// Na kraj niza
countries.push("Austrija");
// Na početak niza
countries.unshift("Francuska");
console.log(countries);

// Micanje elemenata iz niz
// Sa kraj niza
countries.pop();
// Na početak niza
countries.shift();
console.log(countries);

// Brisanje elemenata iz niza
delete countries[1];
console.log(countries);
countries.sort();
console.log(countries);
countries.reverse();
console.log(countries);

var numbers = [
    [1,3,5],
    [2,4,6]
];

var flatNumbers = [];

for(var i = 0; i < numbers.length; i++){
    for(var j = 0; j < numbers[i].length; j++){
        flatNumbers.push(numbers[i][j]);
    }
}
flatNumbers.sort();
console.log(flatNumbers);
// [1,2,3,4,5,6]