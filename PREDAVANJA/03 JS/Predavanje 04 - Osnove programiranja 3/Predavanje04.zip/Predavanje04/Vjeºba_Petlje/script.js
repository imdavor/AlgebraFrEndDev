var number, isRepeat, isPrime;

do {
    number = prompt("Unesi neki broj!");
    number = Number(number);

    if (isNaN(number)) {
        alert("Nisi upisao broj!");
        isRepeat = true;
    } else {
        if (number > 1) {
            for(var i = 2; i < number; i++){
                if (number % i != 0) {
                    isPrime = true;
                } else {
                    isPrime = false;
                    break;
                }
            }

            if (isPrime) {
                console.log("Prosti");
            } else {
                console.log("Nije prosti");
            }
        }

        isRepeat = false;
    }
} while (isRepeat);