var firstName, lastName, price, discount, fullPrice, x, a;

firstName = "John";
lastName = "Doe";

price = 19.9;
discount = 0.1;

if (x == 1){
    x = 2;
    a = 1;
} 

if (a) {
    var z = 44;
    //return 0;
}

fullPrice = (price * 100) / discount;

console.log(fullPrice);


