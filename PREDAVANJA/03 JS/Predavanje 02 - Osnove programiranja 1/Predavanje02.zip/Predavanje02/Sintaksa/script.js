// Deklaracija varijable
var ime;
console.log(ime);

// Inicijalizacija varijable
ime = "Ana";
console.log(ime);

// Deklaracija i inicijalizacija varijable
var prezime = "Anić";
console.log(prezime);

// If izjave bez zagrada NEĆEMO koristiti!
if(5 < 3)
    console.log("radi");
    console.log("i ovo radi");

if(5 > 3){
    console.log("radi");
    console.log("i ovo radi");
}

var fullName = "Pero Perić";

var PascalCase; // Imenovanje klasa
var camelCase; // Imenovanje varijabli, svojstava objekta, funkcija i metoda
var snake_case; // Možemo koristiti za imenovanje svojstava objekta
var UPPER_SNAKE_CASE; // Imenovanje konstanti